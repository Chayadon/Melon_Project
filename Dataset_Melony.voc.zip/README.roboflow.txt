
Melony - v3 1189 pics
==============================

This dataset was exported via roboflow.ai on June 28, 2022 at 3:27 AM GMT

It includes 1189 images.
Disease are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


